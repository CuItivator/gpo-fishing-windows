import difflib
import os
import queue
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
from collections import Counter

import cv2
import numpy as np

SKIP_WORDS = {"collect", "t", "e"}
MAX_LEN = 40
UPSCALE_TO_H = 90
READ_TIMEOUT_S = 8.0
NAME_MATCH = 0.85
_STRIP = re.compile(r"[^A-Za-z0-9 '\-.]")

WINDOWS_READER = r"""
[Console]::OutputEncoding = [Text.Encoding]::UTF8
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$null = [Windows.Storage.StorageFile, Windows.Storage, ContentType = WindowsRuntime]
$null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime]
$null = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Graphics, ContentType = WindowsRuntime]
$null = [Windows.Globalization.Language, Windows.Globalization, ContentType = WindowsRuntime]
$asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
    $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'
})[0]
function Await($op, [Type]$type) {
    $task = $asTask.MakeGenericMethod($type).Invoke($null, @($op))
    $task.Wait(-1) | Out-Null
    $task.Result
}
$engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
if ($null -eq $engine) {
    $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage([Windows.Globalization.Language]::new('en-US'))
}
while ($true) {
    $line = [Console]::In.ReadLine()
    if ($null -eq $line) { break }
    $id, $path = $line.Split([char]'|', 2)
    if (-not $path) { continue }
    $text = ''
    try {
        $file = Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($path)) ([Windows.Storage.StorageFile])
        $stream = Await ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
        $decoder = Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
        $bitmap = Await ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
        $result = Await ($engine.RecognizeAsync($bitmap)) ([Windows.Media.Ocr.OcrResult])
        $text = ($result.Lines | ForEach-Object { $_.Text }) -join '|'
        $stream.Dispose()
    } catch {
        $text = ''
    }
    [Console]::Out.WriteLine("$id|$text")
    [Console]::Out.Flush()
}
"""


def pick_name(lines):
    for line in lines:
        text = " ".join(_STRIP.sub("", str(line)).split())[:MAX_LEN].strip(" .-'")
        if sum(ch.isalpha() for ch in text) >= 2 and text.lower() not in SKIP_WORDS:
            return text
    return None


def fish_key(name):
    return "".join(ch for ch in str(name).lower() if ch.isalnum())


def same_fish(a, b):
    ka, kb = fish_key(a), fish_key(b)
    if not ka or not kb:
        return False
    return ka == kb or difflib.SequenceMatcher(None, ka, kb).ratio() >= NAME_MATCH


def most_common(names):
    groups = []
    for name in names:
        for group in groups:
            if same_fish(group[0], name):
                group.append(name)
                break
        else:
            groups.append([name])
    if not groups:
        return None
    best = max(groups, key=len)
    return Counter(best).most_common(1)[0][0]


def area_crop(frame, area):
    if frame is None or not area:
        return None
    h, w = frame.shape[:2]
    x0 = max(0, int(round(area["x"] * w)))
    y0 = max(0, int(round(area["y"] * h)))
    x1 = min(w, int(round((area["x"] + area["w"]) * w)))
    y1 = min(h, int(round((area["y"] + area["h"]) * h)))
    if x1 - x0 < 4 or y1 - y0 < 4:
        return None
    return frame[y0:y1, x0:x1].copy()


def upscale(crop, target_h=UPSCALE_TO_H):
    scale = max(1.0, min(4.0, target_h / float(max(1, crop.shape[0]))))
    if scale <= 1.0:
        return crop
    return cv2.resize(crop, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)


if sys.platform == "win32":
    class _Engine(object):
        def __init__(self):
            self._proc = None
            self._lines = queue.Queue()
            self._next_id = 0
            self._dir = tempfile.gettempdir()
            self._left = []

        def _start(self):
            self._proc = subprocess.Popen(
                ["powershell", "-NoProfile", "-NonInteractive", "-Command", WINDOWS_READER],
                stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                text=True, encoding="utf-8", bufsize=1,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            self._lines = queue.Queue()
            proc, lines = self._proc, self._lines

            def pump():
                for line in proc.stdout:
                    lines.put(line.rstrip("\r\n"))

            threading.Thread(target=pump, daemon=True).start()

        def warm(self):
            if self._proc is None or self._proc.poll() is not None:
                self._start()
            return ""

        def read(self, crop):
            self._clean()
            self._next_id += 1
            tag = str(self._next_id)
            image = os.path.join(self._dir, "gpo-name-%d-%s.png" % (os.getpid(), tag))
            if not cv2.imwrite(image, upscale(crop)):
                return [], "couldn't write the temp picture"
            self._left.append(image)
            try:
                self.warm()
                self._proc.stdin.write("%s|%s\n" % (tag, image))
                self._proc.stdin.flush()
                end = time.monotonic() + READ_TIMEOUT_S
                while True:
                    got, _, text = self._lines.get(timeout=max(0.01, end - time.monotonic())).partition("|")
                    if got == tag:
                        self._clean()
                        return text.split("|"), ""
            except (OSError, ValueError, queue.Empty):
                self.stop()
                return [], "Windows text reader didn't answer"

        def stop(self):
            proc, self._proc = self._proc, None
            if proc is not None and proc.poll() is None:
                try:
                    proc.stdin.close()
                    proc.wait(timeout=1.0)
                except (OSError, subprocess.TimeoutExpired):
                    proc.kill()
            self._clean()

        def _clean(self):
            keep = []
            for image in self._left:
                try:
                    if os.path.exists(image):
                        os.remove(image)
                except OSError:
                    keep.append(image)
            self._left = keep

elif sys.platform == "darwin":
    class _Engine(object):
        def __init__(self):
            self._vision = None
            self._why = ""

        def warm(self):
            if self._vision is None and not self._why:
                try:
                    import Foundation
                    import objc
                    import Vision
                    self._vision = (Vision, Foundation, objc)
                except Exception:
                    self._why = "the Vision package is missing, run Setup.command again"
            return self._why

        def read(self, crop):
            if self.warm():
                return [], self._why
            Vision, Foundation, objc = self._vision
            ok, png = cv2.imencode(".png", upscale(crop))
            if not ok:
                return [], "couldn't encode the picture"
            raw = png.tobytes()
            with objc.autorelease_pool():
                data = Foundation.NSData.dataWithBytes_length_(raw, len(raw))
                handler = Vision.VNImageRequestHandler.alloc().initWithData_options_(data, {})
                req = Vision.VNRecognizeTextRequest.alloc().init()
                req.setRecognitionLevel_(Vision.VNRequestTextRecognitionLevelAccurate)
                req.setUsesLanguageCorrection_(False)
                done = handler.performRequests_error_([req], None)
                if not (done[0] if isinstance(done, tuple) else done):
                    return [], "macOS text reader failed"
                found = []
                for obs in req.results() or []:
                    top = obs.topCandidates_(1)
                    if top:
                        found.append((-float(obs.boundingBox().origin.y), str(top[0].string())))
            return [text for _, text in sorted(found)], ""

        def stop(self):
            pass

else:
    class _Engine(object):
        def warm(self):
            if shutil.which("tesseract") is None:
                return "tesseract is not installed (sudo apt install tesseract-ocr)"
            return ""

        def read(self, crop):
            why = self.warm()
            if why:
                return [], why
            grey = cv2.cvtColor(upscale(crop, 120), cv2.COLOR_BGR2GRAY)
            _, bw = cv2.threshold(grey, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
            if cv2.countNonZero(bw) < bw.size / 2:
                bw = cv2.bitwise_not(bw)
            bw = cv2.copyMakeBorder(bw, 12, 12, 12, 12, cv2.BORDER_CONSTANT, value=255)
            ok, png = cv2.imencode(".png", bw)
            if not ok:
                return [], "couldn't encode the picture"
            try:
                out = subprocess.run(["tesseract", "stdin", "stdout", "--psm", "6", "-l", "eng"],
                                     input=png.tobytes(), capture_output=True, timeout=READ_TIMEOUT_S)
            except (OSError, subprocess.TimeoutExpired):
                return [], "tesseract didn't answer"
            return out.stdout.decode("utf-8", "replace").splitlines(), ""

        def stop(self):
            pass


class NameReader(object):
    def __init__(self):
        self._engine = _Engine()
        self._lock = threading.Lock()
        self.why = ""

    def warm(self):
        with self._lock:
            try:
                self.why = self._engine.warm()
            except Exception as exc:
                self.why = str(exc)

    def _lines(self, crop):
        if crop is None or crop.size == 0:
            return None, "nothing to read"
        with self._lock:
            try:
                return self._engine.read(np.ascontiguousarray(crop))
            except Exception as exc:
                return [], str(exc)

    def read(self, crop):
        lines, self.why = self._lines(crop)
        if lines is None:
            return None
        name = pick_name(lines)
        if name is None and not self.why:
            self.why = "no text found in the name area"
        return name

    def stop(self):
        with self._lock:
            try:
                self._engine.stop()
            except Exception:
                pass
