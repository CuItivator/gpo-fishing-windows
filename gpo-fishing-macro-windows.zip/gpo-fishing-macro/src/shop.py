import time

import ui
from core import inputs

DEFAULTS = {
    "key": "e",
    "fallback_amount": 100,
    "max_amount": 0,
    "buy_when_bait_below": 0,
    "retry_after": 10,
}

VISIT_BUDGET_S = 60.0


def _type_number(n):
    inputs.key_down(inputs.SELECT_ALL)
    inputs.press("a")
    inputs.key_up(inputs.SELECT_ALL)
    time.sleep(0.08)
    inputs.press("backspace")
    time.sleep(0.08)
    for ch in str(n):
        inputs.press(ch, hold=0.05)
        time.sleep(0.08)


class _Visit(object):
    def __init__(self, screen, cfg, log, stop):
        self.screen, self.cfg, self.log, self.stop = screen, cfg, log, stop
        self.deadline = time.perf_counter() + VISIT_BUDGET_S

    def view(self):
        return ui.View(self.screen)

    def out_of_time(self):
        return self.stop() or time.perf_counter() > self.deadline

    def wait(self, test, timeout):
        t0 = time.perf_counter()
        while time.perf_counter() - t0 < timeout:
            if self.out_of_time():
                return None
            v = self.view()
            if test(v):
                return v
            time.sleep(0.15)
        return None

    def settled(self, measure, timeout=3.0, same=3, gap=0.15):
        t0 = time.perf_counter()
        last, run, v = None, 0, self.view()
        while time.perf_counter() - t0 < timeout and not self.out_of_time():
            v = self.view()
            m = measure(v)
            run = run + 1 if m == last else 1
            last = m
            if run >= same:
                break
            time.sleep(gap)
        return v

    def open_prompt(self):
        key = str(self.cfg["key"])
        for attempt in range(1, 4):
            v = self.view()
            if ui.prompt_open(v) or ui.amount_open(v):
                return v
            self.log("shop: pressing %s at the bait sign%s" % (key.upper(), "" if attempt == 1 else " (try %d)" % attempt))
            inputs.press(key, hold=0.12)
            v = self.wait(lambda v: ui.prompt_open(v) or ui.amount_open(v), 4.0)
            if v is not None:
                return v
            if self.out_of_time():
                return None
        self.log("shop: no purchase prompt came up - stand right next to the bait sign")
        return None

    def accept_prompt(self, v):
        if ui.amount_open(v):
            return v
        self.settled(lambda v: v.count(ui.PROMPT_TEXT, ui.white), timeout=2.5)
        for attempt in range(1, 4):
            self.log("shop: purchase prompt - clicking Yes%s" % ("" if attempt == 1 else " (try %d)" % attempt))
            inputs.click(*v.pt(ui.YES_BTN))
            v = self.wait(ui.amount_open, 8.0)
            if v is not None:
                return v
            if self.out_of_time():
                return None
            v = self.view()
            if not ui.prompt_open(v):
                v = self.wait(ui.amount_open, 4.0)
                if v is not None:
                    return v
                self.log("shop: the prompt closed but no amount box came up")
                return None
        self.log("shop: Yes did not open the amount box")
        return None

    def read_amount(self):
        v = self.settled(lambda v: v.count(ui.MAX_TEXT, ui.yellow), timeout=3.0)
        n, text = ui.read_max(v)
        if n is None:
            n = int(self.cfg["fallback_amount"])
            self.log("shop: could not read the MAX number (%r) - using %d" % (text, n))
        else:
            self.log("shop: MAX is %d" % n)
        cap = int(self.cfg.get("max_amount") or 0)
        if cap > 0:
            n = min(n, cap)
        return n, v

    def buy(self, v, n):
        for attempt in range(1, 4):
            inputs.click(*v.pt(ui.COUNT_BOX))
            time.sleep(0.35)
            _type_number(n)
            time.sleep(0.35)
            self.log("shop: buying %d%s" % (n, "" if attempt == 1 else " (try %d)" % attempt))
            inputs.click(*v.pt(ui.YES_BTN))
            if self.wait(lambda v: not ui.amount_open(v), 5.0) is not None:
                return True
            if self.out_of_time():
                return False
            v = self.view()
        self.log("shop: Buy did not go through")
        return False

    def close_panel(self, known_open):
        time.sleep(0.8)
        for i in range(3):
            v = self.view()
            if ui.prompt_open(v) or ui.amount_open(v):
                return False
            if not (known_open and i == 0) and not ui.dialog_panel(v):
                return True
            inputs.click(*v.pt(ui.COUNT_BOX))
            time.sleep(0.7)
            if self.out_of_time():
                break
        return True

    def cancel(self):
        v = self.view()
        if ui.amount_open(v) or ui.prompt_open(v):
            self.log("shop: closing the dialogue")
            inputs.click(*v.pt(ui.NO_BTN))
            if self.wait(lambda v: not (ui.amount_open(v) or ui.prompt_open(v)), 4.0) is None:
                inputs.click(*v.pt(ui.NO_BTN))
                time.sleep(0.8)
            self.close_panel(known_open=True)
        else:
            self.close_panel(known_open=False)

    def run(self):
        v = self.open_prompt()
        if v is None:
            return False
        v = self.accept_prompt(v)
        if v is None:
            return False
        time.sleep(0.3)
        n, v = self.read_amount()
        if n <= 0:
            self.log("shop: MAX is 0 - no money for bait, cancelling")
            return False
        if not self.buy(v, n):
            return False
        self.close_panel(known_open=True)
        self.log("shop: bought %d bait" % n)
        return True


def buy_bait(screen, cfg, log, stop):
    visit = _Visit(screen, cfg, log, stop)
    ok = False
    try:
        ok = visit.run()
    finally:
        if not ok and not stop():
            visit.cancel()
    return ok
