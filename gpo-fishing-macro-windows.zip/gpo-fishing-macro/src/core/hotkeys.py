import time

import keyboard

MODIFIERS = {"ctrl", "shift", "alt", "windows", "alt gr"}

SCAN = {7: 71, 8: 72, 9: 73,
        4: 75, 5: 76, 6: 77,
        1: 79, 2: 80, 3: 81,
        0: 82}

ACTIONS = [
    ("toggle", "start / stop fishing"),
    ("cast_pos", "set the cast spot"),
    ("quit", "quit"),
]

DEFAULT_KEYS = {
    "toggle": "f1",
    "cast_pos": "f4",
    "quit": "f3",
}


def is_numpad(event, digit):
    return event.scan_code == SCAN[digit] and getattr(event, "is_keypad", False)


def on_numpad(digit, callback):
    return keyboard.on_press(lambda e: is_numpad(e, digit) and callback())


def keys_from(cfg):
    out = dict(DEFAULT_KEYS)
    for k, v in (cfg.get("hotkeys") or {}).items():
        if k in out and isinstance(v, str) and v.strip():
            out[k] = v.strip().lower()
    return out


def numpad_digit(spec):
    parts = (spec or "").strip().lower().split()
    if len(parts) == 2 and parts[0] == "numpad" and parts[1].isdigit():
        d = int(parts[1])
        if d in SCAN:
            return d
    return None


def valid(spec):
    spec = (spec or "").strip().lower()
    if not spec:
        return False, "empty"
    if numpad_digit(spec) is not None:
        return True, ""
    try:
        keyboard.parse_hotkey(spec)
    except Exception as exc:
        return False, str(exc)
    return True, ""


def bind(spec, callback):
    d = numpad_digit(spec)
    if d is not None:
        handle = on_numpad(d, callback)
        return lambda: keyboard.unhook(handle)
    handle = keyboard.add_hotkey(spec, callback)
    return lambda: keyboard.remove_hotkey(handle)


def is_pressed(name):
    return keyboard.is_pressed(name)


def _canon(name):
    name = (name or "").lower()
    for side in ("left ", "right "):
        if name.startswith(side):
            name = name[len(side):]
    return name


def read_key():
    held = set()
    time.sleep(0.25)
    while True:
        e = keyboard.read_event()
        name = _canon(e.name)
        if e.event_type == "down":
            if name in MODIFIERS:
                held.add(name)
                continue
            if name in ("esc", "escape"):
                spec = None
            elif getattr(e, "is_keypad", False) and e.scan_code in SCAN.values():
                digit = [d for d, sc in SCAN.items() if sc == e.scan_code][0]
                spec = "numpad %d" % digit
            else:
                spec = "+".join(sorted(held) + [name])
            deadline = time.time() + 2.0
            while time.time() < deadline:
                r = keyboard.read_event()
                if r.event_type == "up" and _canon(r.name) == name:
                    break
            return spec
        else:
            held.discard(name)


def label(spec):
    d = numpad_digit(spec)
    if d is not None:
        return "Numpad %d" % d
    return "+".join(p.strip().capitalize() if len(p.strip()) > 1 else p.strip().upper()
                    for p in (spec or "").split("+"))
