import ctypes
import os

import mss
import numpy as np


def dpi_aware():
    if os.name != "nt":
        return
    try:
        ctypes.windll.user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
    except Exception:
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)
        except Exception:
            pass


def roblox_client():
    if os.name != "nt":
        return None
    try:
        u = ctypes.windll.user32
        hwnd = u.FindWindowW(None, "Roblox")
        if not hwnd:
            return None

        class R(ctypes.Structure):
            _fields_ = [("l", ctypes.c_long), ("t", ctypes.c_long), ("r", ctypes.c_long), ("b", ctypes.c_long)]

        class P(ctypes.Structure):
            _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]

        r, p = R(), P(0, 0)
        if not u.GetClientRect(hwnd, ctypes.byref(r)) or not u.ClientToScreen(hwnd, ctypes.byref(p)):
            return None
        w, h = r.r - r.l, r.b - r.t
        if w < 200 or h < 200:
            return None
        return p.x, p.y, w, h
    except Exception:
        return None


class Screen(object):
    def __init__(self):
        self.sct = (getattr(mss, "MSS", None) or mss.mss)()
        self.mon = dict(self.sct.monitors[1])
        probe = self.sct.grab(self.mon)
        self.scale = float(probe.width) / float(self.mon["width"])

    def grab(self, region=None):
        r = region or self.mon
        img = np.asarray(self.sct.grab(r))[:, :, :3]
        off = (int(round(r["left"] * self.scale)), int(round(r["top"] * self.scale)))
        return np.ascontiguousarray(img), off

    def to_points(self, v):
        return int(round(v / self.scale))

    def to_pixels(self, v):
        return int(round(v * self.scale))

    def bounds(self):
        return self.mon

    def client(self):
        c = roblox_client()
        if c:
            return c
        m = self.mon
        return m["left"], m["top"], m["width"], m["height"]
