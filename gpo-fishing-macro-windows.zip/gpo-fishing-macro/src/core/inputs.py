import ctypes
import time

import pydirectinput as pdi

pdi.PAUSE = 0.0
pdi.FAILSAFE = False

_u32 = ctypes.windll.user32

MOUSEEVENTF_MOVE = 0x0001
MOUSEEVENTF_LEFTDOWN = 0x0002
MOUSEEVENTF_LEFTUP = 0x0004
MOUSEEVENTF_VIRTUALDESK = 0x4000
MOUSEEVENTF_ABSOLUTE = 0x8000
SM_XVIRTUALSCREEN, SM_YVIRTUALSCREEN, SM_CXVIRTUALSCREEN, SM_CYVIRTUALSCREEN = 76, 77, 78, 79

_ALIAS = {"ctrl": "ctrl", "control": "ctrl", "alt": "alt", "shift": "shift",
          "cmd": "win", "win": "win", "enter": "enter", "return": "enter",
          "esc": "esc", "escape": "esc", "backspace": "backspace",
          "space": "space", "tab": "tab", "delete": "delete"}

_down = False
SELECT_ALL = "ctrl"


class _Point(ctypes.Structure):
    _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]


def cursor_pos():
    p = _Point()
    _u32.GetCursorPos(ctypes.byref(p))
    return [p.x, p.y]


def _mouse(flags):
    _u32.mouse_event(flags, 0, 0, 0, 0)


def _abs_move(x, y):
    vx, vy = _u32.GetSystemMetrics(SM_XVIRTUALSCREEN), _u32.GetSystemMetrics(SM_YVIRTUALSCREEN)
    vw, vh = _u32.GetSystemMetrics(SM_CXVIRTUALSCREEN), _u32.GetSystemMetrics(SM_CYVIRTUALSCREEN)
    nx = int(round((x - vx) * 65535.0 / max(1, vw - 1)))
    ny = int(round((y - vy) * 65535.0 / max(1, vh - 1)))
    _u32.mouse_event(MOUSEEVENTF_MOVE | MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_VIRTUALDESK, nx, ny, 0, 0)


def move_to(x, y, steps=6):
    x, y = int(x), int(y)
    x0, y0 = cursor_pos()
    for i in range(1, steps + 1):
        t = i / float(steps)
        _abs_move(x0 + (x - x0) * t, y0 + (y - y0) * t)
        time.sleep(0.012)
    _u32.SetCursorPos(x, y)
    _abs_move(x, y)
    time.sleep(0.01)


def _wiggle():
    for dx, dy in ((2, 1), (-2, -1), (1, 0), (-1, 0)):
        _u32.mouse_event(MOUSEEVENTF_MOVE, dx, dy, 0, 0)
        time.sleep(0.015)


def mouse_down():
    global _down
    _mouse(MOUSEEVENTF_LEFTDOWN)
    _down = True


def mouse_up():
    global _down
    _mouse(MOUSEEVENTF_LEFTUP)
    _down = False


def click(x, y, press=0.09):
    move_to(x, y)
    _wiggle()
    time.sleep(0.06)
    mouse_down()
    time.sleep(press)
    mouse_up()
    time.sleep(0.03)


def drag(x0, y0, x1, y1, steps=12, hold=0.15):
    move_to(x0, y0)
    _wiggle()
    time.sleep(0.08)
    mouse_down()
    time.sleep(hold)
    for i in range(1, steps + 1):
        t = i / float(steps)
        _abs_move(x0 + (x1 - x0) * t, y0 + (y1 - y0) * t)
        time.sleep(0.02)
    _u32.SetCursorPos(int(x1), int(y1))
    _abs_move(x1, y1)
    time.sleep(hold)
    mouse_up()
    time.sleep(0.05)


def _name(key):
    return _ALIAS.get(str(key).strip().lower(), str(key).strip().lower())


def key_down(key):
    pdi.keyDown(_name(key))


def key_up(key):
    pdi.keyUp(_name(key))


def press(key, hold=0.03):
    name = _name(key)
    pdi.keyDown(name)
    time.sleep(max(hold, 0.0))
    pdi.keyUp(name)


def button_down():
    return bool(_u32.GetAsyncKeyState(0x01) & 0x8000)


def esc_down():
    return bool(_u32.GetAsyncKeyState(0x1B) & 0x8000)


def roblox_in_front():
    try:
        h = _u32.FindWindowW(None, "Roblox")
        return bool(h) and _u32.GetForegroundWindow() == h
    except Exception:
        return False


def focus_roblox():
    try:
        h = _u32.FindWindowW(None, "Roblox")
        if not h:
            return False
        if _u32.GetForegroundWindow() == h:
            return True
        _u32.keybd_event(0xA4, 0, 0, 0)
        _u32.keybd_event(0xA4, 0, 2, 0)
        if _u32.IsIconic(h):
            _u32.ShowWindow(h, 9)
        _u32.SetForegroundWindow(h)
        time.sleep(0.3)
        return _u32.GetForegroundWindow() == h
    except Exception:
        return False


def check_permissions(log):
    return True
