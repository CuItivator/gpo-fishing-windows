import json
import os
import re

import cv2
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
PATH = os.path.join(HERE, "assets", "digits.json")
W, H = 20, 28
SMALL_H = 24
_T = None


def _templates():
    global _T
    if _T is None:
        _T = {}
        try:
            with open(PATH) as f:
                raw = json.load(f)
            for d, samples in raw.items():
                _T[d] = [np.array(s, dtype=bool).reshape(H, W) for s in samples]
        except (OSError, ValueError):
            pass
    return _T


def strip_lines(mask, min_len=20):
    m = mask.astype(np.uint8)
    if m.size == 0:
        return mask.astype(bool)
    horiz = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((1, min_len), np.uint8))
    vert = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((min_len, 1), np.uint8))
    return (m > 0) & (horiz == 0) & (vert == 0)


def boxes(mask, min_h=0.45):
    m = mask.astype(np.uint8)
    n, _lab, stats, _c = cv2.connectedComponentsWithStats(m, connectivity=8)
    comps = [(x, y, w, h) for x, y, w, h, a in stats[1:] if a >= 4 and w >= 3 and h >= 4]
    if not comps:
        return []
    comps.sort()
    merged = []
    for x, y, w, h in comps:
        if merged:
            mx, my, mw, mh = merged[-1]
            overlap = min(mx + mw, x + w) - max(mx, x)

            if overlap >= 0.6 * min(w, mw):
                x0, y0 = min(mx, x), min(my, y)
                x1, y1 = max(mx + mw, x + w), max(my + mh, y + h)
                merged[-1] = (x0, y0, x1 - x0, y1 - y0)
                continue
        merged.append((x, y, w, h))
    top = max(h for _x, _y, _w, h in merged)
    return [b for b in merged if b[3] >= min_h * top]


def norm(mask, box):
    x, y, w, h = box
    g = mask[y:y + h, x:x + w].astype(np.uint8) * 255
    g = cv2.resize(g, (W, H), interpolation=cv2.INTER_AREA)
    return g >= 128


def classify(vec):
    best, score = None, 0.0
    for d, samples in _templates().items():
        for t in samples:
            inter = np.logical_and(vec, t).sum()
            union = np.logical_or(vec, t).sum()
            s = inter / float(union) if union else 0.0
            if s > score:
                best, score = d, s
    return best, score


def read_text(mask, min_score=0.5):
    out = []
    for b in boxes(mask):
        d, s = classify(norm(mask, b))
        out.append(d if d is not None and s >= min_score else "?")
    return "".join(out)


def read_number(mask, after_gap=False):
    if mask is None or not mask.any():
        return None, ""
    mask = strip_lines(mask)
    if mask.shape[0] < SMALL_H:
        mask = np.repeat(np.repeat(mask, 2, axis=0), 2, axis=1)
    if after_gap:
        cols = np.where(mask.any(axis=0))[0]
        gaps = np.diff(cols)
        if len(gaps) and gaps.max() >= 4:
            mask = mask[:, cols[int(np.argmax(gaps)) + 1]:]
    text = read_text(mask)

    m = re.match(r"^\?*(\d+)$", text)
    if not m:
        return None, text
    return int(m.group(1)), text
