from dataclasses import dataclass
from typing import Optional

import cv2
import numpy as np

DARK_RGB = np.array([25, 25, 25], np.float32)
BLUE_RGB = np.array([85, 170, 255], np.float32)
WHITE_RGB = np.array([255, 255, 255], np.float32)
BLUE_TOL = 10
DARK_TOL = 8
WHITE_MIN = 225
SEG_TOL = 18

MIN_RUN = 60
MIN_WIDTH, MAX_WIDTH = 2, 60
MIN_ASPECT = 6.0
MIN_BLUE_FRAC = 0.12
GAP_CLOSE = 5
CTRL_FRAC_GUESS = 0.255


@dataclass
class Bar:
    x0: int
    x1: int
    y0: int
    y1: int
    border: int
    ctrl_top: Optional[float]
    ctrl_bot: Optional[float]
    ctrl_clean: bool
    fish_y: Optional[float]

    @property
    def height(self):
        return self.y1 - self.y0 + 1

    @property
    def width(self):
        return self.x1 - self.x0 + 1

    @property
    def ctrl_y(self):
        if self.ctrl_top is None:
            return None
        return (self.ctrl_top + self.ctrl_bot) / 2

    @property
    def ctrl_len(self):
        if self.ctrl_top is None:
            return None
        return self.ctrl_bot - self.ctrl_top + 1


def strict_masks(bgr):
    r, g, b = BLUE_RGB
    lo = np.array([b - BLUE_TOL, g - BLUE_TOL, r - BLUE_TOL], np.uint8)
    hi = np.array([min(255, b + BLUE_TOL), min(255, g + BLUE_TOL), min(255, r + BLUE_TOL)], np.uint8)
    blue = cv2.inRange(bgr, lo, hi)
    d = int(DARK_RGB[0])
    dark = cv2.inRange(bgr, (d - DARK_TOL,) * 3, (d + DARK_TOL,) * 3)
    white = cv2.inRange(bgr, (WHITE_MIN,) * 3, (255, 255, 255))
    return blue > 0, dark > 0, white > 0


def _seg_dist(rgb, a, b):
    d = b - a
    t = ((rgb - a) @ d) / float(d @ d)
    t = np.clip(t, 0, 1)
    proj = a + t[..., None] * d
    return np.linalg.norm(rgb - proj, axis=-1), t


def onbar_masks(bgr):
    rgb = bgr[..., ::-1].astype(np.float32)
    d1, t1 = _seg_dist(rgb, DARK_RGB, BLUE_RGB)
    d2, _ = _seg_dist(rgb, BLUE_RGB, WHITE_RGB)
    d3, _ = _seg_dist(rgb, DARK_RGB, WHITE_RGB)
    on1 = d1 <= SEG_TOL
    onbar = on1 | (d2 <= SEG_TOL) | (d3 <= SEG_TOL)
    darkish = on1 & (t1 <= 0.6)
    return onbar, darkish


def _runs(bools):
    if not bools.any():
        return []
    d = np.diff(np.concatenate(([0], bools.view(np.uint8), [0])))
    starts = np.where(d == 1)[0]
    ends = np.where(d == -1)[0] - 1
    return list(zip(starts.tolist(), ends.tolist()))


def _outline(darkish, x, step):
    w = darkish.shape[1]
    x += step
    gap = 0
    while 0 <= x < w and gap < 3 and darkish[:, x].mean() < 0.7:
        x += step
        gap += 1
    n = 0
    while 0 <= x < w and n < 16 and darkish[:, x].mean() >= 0.7:
        x += step
        n += 1
    return n


class Detector:
    def __init__(self):
        self.frac_hist = []
        self.last_ctrl_y = None

    def find(self, bgr, offset=(0, 0)) -> Optional[Bar]:
        H, W = bgr.shape[:2]
        blue, dark, white = strict_masks(bgr)
        barish = (blue | dark | white).view(np.uint8)
        barish = cv2.morphologyEx(barish, cv2.MORPH_CLOSE, np.ones((GAP_CLOSE, 1), np.uint8))
        kern = np.ones((MIN_RUN, 1), np.uint8)
        core = cv2.erode(barish, kern)
        if not core.any():
            return None
        run = cv2.dilate(core, kern).astype(bool)

        run_len = run.sum(axis=0)
        blue_in_run = (blue & run).sum(axis=0)
        interior = (run_len >= MIN_RUN) & (blue_in_run >= MIN_BLUE_FRAC * np.maximum(run_len, 1))

        best = None
        for x0, x1 in _runs(interior):
            w = x1 - x0 + 1
            if not (MIN_WIDTH <= w <= MAX_WIDTH):
                continue
            rows = run[:, x0:x1 + 1].sum(axis=1) >= (w + 1) // 2
            r = _runs(rows)
            if not r:
                continue
            ry0, ry1 = max(r, key=lambda p: p[1] - p[0])
            h = ry1 - ry0 + 1
            cx0, cx1 = max(0, x0 - 20), min(W, x1 + 21)
            crop = bgr[ry0:ry1 + 1, cx0:cx1]
            onbar, darkish = onbar_masks(crop)
            blue_rows = blue[ry0:ry1 + 1, x0:x1 + 1].sum(axis=1) >= (w + 1) // 2
            if blue_rows.sum() < 10:
                continue
            dk = darkish[blue_rows]
            border = min(_outline(dk, x0 - cx0, -1), _outline(dk, x1 - cx0, +1))
            if border < 1:
                continue
            if h < MIN_ASPECT * (w + 2 * border):
                continue
            score = int(blue[ry0:ry1 + 1, x0:x1 + 1].sum())
            if best is None or score > best[0]:
                best = (score, x0, x1, ry0, ry1, border)
        if best is None:
            return None

        _, x0, x1, ry0, ry1, border = best
        w = x1 - x0 + 1
        half = (w + 1) // 2
        sl = slice(x0, x1 + 1)
        row_blue = blue[ry0:ry1 + 1, sl].sum(axis=1) >= half
        row_white = white[ry0:ry1 + 1, sl].sum(axis=1) >= half
        row_dark = dark[ry0:ry1 + 1, sl].sum(axis=1) >= half
        n = len(row_blue)

        bruns = []
        for a, b in _runs(row_blue):
            if bruns:
                pa, pb = bruns[-1]
                gap = slice(pb + 1, a)
                if row_dark[gap].mean() < 0.4:
                    bruns[-1] = (pa, b)
                    continue
            bruns.append((a, b))
        if not bruns:
            return None

        frac = self._frac_est()
        ct = cb = None
        clean = False
        if len(bruns) >= 2:
            interior_h = bruns[-1][1] - bruns[0][0] + 1
            gaps = [(bruns[i][1] + 1, bruns[i + 1][0] - 1) for i in range(len(bruns) - 1)]
            gt, gb = min(gaps, key=lambda g: abs((g[1] - g[0] + 1) - frac * interior_h))
            y0, y1 = bruns[0][0], bruns[-1][1]
            ct, cb = gt, gb
            clean = True
            length = cb - ct + 1
            if 0.1 * interior_h < length < 0.6 * interior_h:
                self.frac_hist.append(length / interior_h)
                if len(self.frac_hist) > 60:
                    self.frac_hist.pop(0)
        else:
            bt, bb = bruns[0]
            blue_len = bb - bt + 1
            interior_h = blue_len / (1.0 - frac)
            zone_len = frac * interior_h
            above = bt
            below = n - 1 - bb
            thresh = border + max(3, 0.03 * interior_h)
            top_ok, bot_ok = above > thresh, below > thresh
            if top_ok and bot_ok and self.last_ctrl_y is not None:
                top_ok = abs((bt - zone_len / 2) - (self.last_ctrl_y - offset[1] - ry0)) <= \
                         abs((bb + zone_len / 2) - (self.last_ctrl_y - offset[1] - ry0))
                bot_ok = not top_ok
            elif top_ok and bot_ok:
                top_ok, bot_ok = above >= below, above < below
            if top_ok:
                cb = bt - 1
                ct = cb - zone_len + 1
                y0, y1 = int(round(ct)), bb
            elif bot_ok:
                ct = bb + 1
                cb = ct + zone_len - 1
                y0, y1 = bt, int(round(cb))
            else:
                y0, y1 = bt, bb

        fish = None
        wr = _runs(row_white)
        if wr:
            ft, fb = max(wr, key=lambda p: p[1] - p[0])
            if fb - ft + 1 <= max(8, 0.06 * (y1 - y0 + 1)):
                fish = (ft + fb) / 2

        ox, oy = offset
        if ct is not None:
            ct, cb = ct + ry0 + oy, cb + ry0 + oy
            self.last_ctrl_y = (ct + cb) / 2
        return Bar(x0 + ox, x1 + ox, y0 + ry0 + oy, y1 + ry0 + oy, border,
                   ct, cb, clean, None if fish is None else fish + ry0 + oy)

    def _frac_est(self):
        if len(self.frac_hist) >= 3:
            return float(np.median(self.frac_hist))
        return CTRL_FRAC_GUESS
