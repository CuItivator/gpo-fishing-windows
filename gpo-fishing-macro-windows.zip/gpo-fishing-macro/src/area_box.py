import tkinter as tk

HANDLE = 10
MIN_W = 40
MIN_H = 40
BORDER = 2
CURSORS = {
    "move": "fleur",
    "n": "sb_v_double_arrow", "s": "sb_v_double_arrow",
    "e": "sb_h_double_arrow", "w": "sb_h_double_arrow",
    "ne": "top_right_corner", "nw": "top_left_corner",
    "se": "bottom_right_corner", "sw": "bottom_left_corner",
}


def clamp(rect, bounds):
    x, y, w, h = rect
    bx, by, bw, bh = bounds
    w = max(MIN_W, min(w, bw))
    h = max(MIN_H, min(h, bh))
    x = max(bx, min(x, bx + bw - w))
    y = max(by, min(y, by + bh - h))
    return (int(x), int(y), int(w), int(h))


def to_pixels(area, bounds):
    bx, by, bw, bh = bounds
    return (int(round(bx + area["x"] * bw)), int(round(by + area["y"] * bh)),
            max(1, int(round(area["w"] * bw))), max(1, int(round(area["h"] * bh))))


def to_fractions(rect, bounds):
    x, y, w, h = rect
    bx, by, bw, bh = bounds
    fx = max(0.0, min(1.0, (x - bx) / float(max(bw, 1))))
    fy = max(0.0, min(1.0, (y - by) / float(max(bh, 1))))
    fw = max(0.01, min(1.0 - fx, w / float(max(bw, 1))))
    fh = max(0.01, min(1.0 - fy, h / float(max(bh, 1))))
    return {"x": fx, "y": fy, "w": fw, "h": fh}


class AreaBox(tk.Toplevel):
    def __init__(self, master, rect, bounds, on_saved, on_cancelled):
        super().__init__(master)
        self.on_saved = on_saved
        self.on_cancelled = on_cancelled
        self._done = False
        self._bounds = bounds
        self.rect = clamp(rect, bounds)
        self._mode = None
        self._origin_mouse = (0, 0)
        self._origin_rect = self.rect

        self.overrideredirect(True)
        self.attributes("-topmost", True)
        try:
            self.attributes("-alpha", 0.45)
        except tk.TclError:
            pass
        self.configure(bg="#c47a3a")
        self._body = tk.Frame(self, bg="#352e26", cursor="fleur")
        self._body.pack(fill="both", expand=True, padx=BORDER, pady=BORDER)
        for widget in (self, self._body):
            widget.bind("<ButtonPress-1>", self._on_press)
            widget.bind("<B1-Motion>", self._on_drag)
            widget.bind("<ButtonRelease-1>", self._on_release)
        self.bind("<Return>", lambda _e: self.save())
        self.bind("<Escape>", lambda _e: self.cancel())
        self.protocol("WM_DELETE_WINDOW", self.cancel)
        self._apply()
        self.focus_force()
        self.grab_set()

    def _apply(self):
        self.rect = clamp(self.rect, self._bounds)
        x, y, w, h = self.rect
        self.geometry("%dx%d+%d+%d" % (w, h, x, y))

    def _zone(self, x, y):
        w, h = self.rect[2], self.rect[3]
        left, right = x < HANDLE, x >= w - HANDLE
        top, bottom = y < HANDLE, y >= h - HANDLE
        if top and left:
            return "nw"
        if top and right:
            return "ne"
        if bottom and left:
            return "sw"
        if bottom and right:
            return "se"
        if left:
            return "w"
        if right:
            return "e"
        if top:
            return "n"
        if bottom:
            return "s"
        return "move"

    def _on_press(self, _event):
        x = self.winfo_pointerx() - self.winfo_rootx()
        y = self.winfo_pointery() - self.winfo_rooty()
        self._mode = self._zone(x, y)
        self._origin_mouse = (self.winfo_pointerx(), self.winfo_pointery())
        self._origin_rect = self.rect
        self.configure(cursor=CURSORS.get(self._mode, "arrow"))

    def _on_drag(self, _event):
        if not self._mode:
            return
        dx = self.winfo_pointerx() - self._origin_mouse[0]
        dy = self.winfo_pointery() - self._origin_mouse[1]
        ox, oy, ow, oh = self._origin_rect
        x, y, w, h = ox, oy, ow, oh
        mode = self._mode
        if mode == "move":
            x, y = ox + dx, oy + dy
        else:
            if "e" in mode:
                w = ow + dx
            if "s" in mode:
                h = oh + dy
            if "w" in mode:
                x, w = ox + dx, ow - dx
            if "n" in mode:
                y, h = oy + dy, oh - dy
        if w < MIN_W:
            x = ox + ow - MIN_W if "w" in mode else x
            w = MIN_W
        if h < MIN_H:
            y = oy + oh - MIN_H if "n" in mode else y
            h = MIN_H
        self.rect = (x, y, w, h)
        self._apply()

    def _on_release(self, _event):
        self._mode = None
        self.configure(cursor="arrow")

    def _finish(self, saved):
        if self._done:
            return
        self._done = True
        try:
            self.grab_release()
        except tk.TclError:
            pass
        rect = clamp(self.rect, self._bounds)
        self.destroy()
        if saved:
            self.on_saved(rect)
        else:
            self.on_cancelled()

    def save(self):
        self._finish(True)

    def cancel(self):
        self._finish(False)
