import time

import ui
from core import inputs

BACKPACK_KEY = "`"


def _wait(screen, test, timeout, stop):
    t0 = time.perf_counter()
    while time.perf_counter() - t0 < timeout:
        if stop():
            return None
        v = ui.View(screen)
        if test(v):
            return v
        time.sleep(0.15)
    return None


def ensure_rod(screen, cfg, log, stop=lambda: False):
    v = ui.View(screen)
    if ui.rod_equipped(v):
        return True
    key = str(cfg["rod_key"])

    for _ in range(2):
        inputs.press(key)
        v = _wait(screen, ui.rod_equipped, 1.5, stop)
        if v is not None:
            return True
        if stop():
            return False
    log("storage: could not see the rod being equipped (slot %s) - casting anyway" % key)
    return False


def store_extras(screen, cfg, log, stop):
    v = ui.View(screen)
    n = v.hotbar_slots()
    if n <= 1 or n == ui.MAX_SLOTS:
        return False
    log("storage: hotbar shows %d slots - putting the extras away" % n)
    stored = False
    for _attempt in range(4):
        if stop():
            break
        v = ui.View(screen)
        n = v.hotbar_slots()
        if n <= 1 or n == ui.MAX_SLOTS:
            break

        inputs.press("2")
        time.sleep(0.8)
        v = ui.View(screen)
        if ui.store_button(v):
            log("storage: Store Fruit")
            inputs.click(*v.pt(ui.STORE_CLICK))
            time.sleep(1.5)
            v = ui.View(screen)
            if v.hotbar_slots() < n:
                stored = True
                continue
            log("storage: Store Fruit did not take it - using the backpack")
        inputs.press(BACKPACK_KEY)
        v = _wait(screen, ui.backpack_open, 3.0, stop)
        if v is None:
            log("storage: the backpack did not open")
            break
        time.sleep(0.3)
        sx, sy = v.slot_centre(1, ui.MAX_SLOTS)
        tx, ty = v.pt(ui.BACKPACK_DROP)
        inputs.drag(sx, sy, tx, ty)
        time.sleep(0.6)
        inputs.press(BACKPACK_KEY)
        _wait(screen, lambda v: not ui.backpack_open(v), 3.0, stop)
        time.sleep(0.4)
        v = ui.View(screen)
        if v.hotbar_slots() < n:
            stored = True
            log("storage: moved it into the backpack")
        else:
            log("storage: the item is still on the hotbar")
    ensure_rod(screen, cfg, log, stop)
    return stored
