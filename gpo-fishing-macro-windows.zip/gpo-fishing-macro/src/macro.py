import os
import threading
import time

import numpy as np

from core import capture, inputs
from detect import Detector
import baits
import names
import shop
import storage
import ui
import webhook

WEBHOOK_FAIL_SEC = 60
WEBHOOK_DC_SEC = 180
CAUGHT_COLOR = 0x57F287
ALERT_COLOR = 0xED4245
NAME_READ_TRIES = 3
NAME_READ_GAP_S = 0.3
LOG_TEXT_MAX = 3800
FISH_MARK = "\U0001f41f"


class Motion(object):
    def __init__(self, alpha=0.8, beta=0.6):
        self.alpha, self.beta = alpha, beta
        self.y = self.v = None
        self.t = None

    def reset(self, y, t):
        self.y, self.v, self.t = float(y), 0.0, t

    def predict(self, t, a):
        dt = max(0.0, t - self.t)
        return self.y + self.v * dt + 0.5 * a * dt * dt, self.v + a * dt

    def update(self, y_meas, t, a, jump):
        if self.y is None:
            self.reset(y_meas, t)
            return
        yp, vp = self.predict(t, a)
        dt = max(1e-3, t - self.t)
        r = y_meas - yp
        if abs(r) > jump:
            self.y, self.v = float(y_meas), vp
        else:
            self.y = yp + self.alpha * r
            self.v = vp + self.beta * r / dt
        self.t = t


class Macro(object):
    def __init__(self, cfg, status=None, save=None):
        self.cfg = cfg
        self.adv = cfg["advanced"]
        self.status = status or (lambda _m: None)
        self.save = save or (lambda: None)
        self.det = Detector()
        self.screen = None
        self.held = False
        self.catches = 0
        self.state = "idle"
        self.last_bar = None
        self._stop = threading.Event()
        self._thread = None
        self._last_shop = 0
        self._last_shop_failed = False
        self.bait = None
        self.bait_name = None
        self.webhook = webhook.Webhook()
        self.names = names.NameReader()
        self.live_log = webhook.LiveMessage()
        self.tally = {}
        self.unread = 0
        self.last_fish = None
        self._tally_lock = threading.Lock()
        self._run_started = time.monotonic()
        self._last_catch = self._run_started
        self._fail_sent = False
        self._dc_sent = 0

    @property
    def running(self):
        return self._thread is not None and self._thread.is_alive()

    def has_cast(self):
        return bool(self.cfg.get("cast_pos"))

    def start(self):
        if self.running:
            return True
        if not self.has_cast():
            return False
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        return True

    def stop(self):
        self._stop.set()
        self.release()
        self.state = "idle"

    def toggle(self):
        if self.running:
            self.stop()
            return True
        return self.start()

    def close(self):
        self.stop()
        self.names.stop()

    def name_read_on(self):
        return bool(self.cfg.get("name_read") and self.cfg.get("name_area"))

    def warm_names(self):
        threading.Thread(target=self.names.warm, daemon=True).start()

    def _idle(self, sec):
        return self._stop.wait(max(0.0, sec))

    def set_cast(self):
        self.cfg["cast_pos"] = inputs.cursor_pos()
        self.save()
        self.status("cast spot saved at %d, %d" % tuple(self.cfg["cast_pos"]))

    def hold(self, want):
        if want == self.held:
            return
        if want:
            inputs.mouse_down()
        else:
            inputs.mouse_up()
        self.held = want

    def release(self):
        self.hold(False)

    def roi_for(self, bar):
        s = self.screen
        h = bar.height
        b = s.bounds()
        left = max(b["left"], s.to_points(bar.x0 - 120))
        top = max(b["top"], s.to_points(bar.y0 - 0.45 * h - 20))
        right = min(b["left"] + b["width"], s.to_points(bar.x1 + 120))
        bottom = min(b["top"] + b["height"], s.to_points(bar.y1 + 0.45 * h + 20))
        return {"left": left, "top": top, "width": max(1, right - left), "height": max(1, bottom - top)}

    def find_full(self):
        img, off = self.screen.grab()
        return self.det.find(img, off)

    def cast(self):
        x, y = self.cfg["cast_pos"]
        inputs.move_to(x, y)
        time.sleep(self.cfg["cast_delay_s"])
        inputs.mouse_down()
        time.sleep(0.06)
        inputs.mouse_up()

    def reset_rod(self):
        self.rod_off_on("no minigame for %.0fs - switching the rod off and on" % self.cfg["cast_wait_s"])

    def wait_for_bar(self):
        t0 = time.perf_counter()
        hits = 0
        while not self._stop.is_set():
            bar = self.find_full()
            if bar is not None:
                hits += 1
                if hits >= 2:
                    return bar, False
            else:
                hits = 0
            if time.perf_counter() - t0 > self.cfg["cast_wait_s"]:
                return None, True
            self._idle(0.3)
        return None, False

    def play(self, bar):
        a = self.adv
        period = 1.0 / a["loop_hz"]
        zone, fish = Motion(), Motion(alpha=0.6, beta=0.3)
        t = time.perf_counter()
        zone.reset(bar.ctrl_y if bar.ctrl_y is not None else (bar.y0 + bar.y1) / 2, t)
        if bar.fish_y is not None:
            fish.reset(bar.fish_y, t)
        roi = self.roi_for(bar)
        last_crop = None
        last_seen = t
        fish_seen = t if bar.fish_y is not None else None
        t_start = t
        h = float(bar.height)

        while not self._stop.is_set():
            t_tick = time.perf_counter()
            crop, off = self.screen.grab(roi)
            bar = self.det.find(crop, off)
            if bar is None:
                bar = self.find_full()
            now = time.perf_counter()
            if bar is None:
                if now - last_seen > a["lost_timeout_s"]:
                    self.release()
                    return now - t_start
                if now - last_seen > 0.3:
                    self.release()
                rest = period - (time.perf_counter() - t_tick)
                if rest > 0:
                    time.sleep(rest)
                continue
            last_seen = now
            self.last_bar = bar
            roi = self.roi_for(bar)
            h = 0.8 * h + 0.2 * bar.height
            same = last_crop is not None and last_crop.shape == crop.shape and np.array_equal(last_crop, crop)
            last_crop = crop
            if not same:
                a_applied = -a["accel"] * h if self.held else a["accel"] * h
                if bar.ctrl_y is not None:
                    zone.update(bar.ctrl_y, now, a_applied, jump=0.25 * h)
                if bar.fish_y is not None:
                    fish.update(bar.fish_y, now, 0.0, jump=0.25 * h)
                    fish_seen = now

            if fish.y is None or now - fish_seen > a["fish_hold_s"]:
                self.release()
            else:
                if now - fish_seen > 0.1:
                    fish.v = 0.0
                self.hold(self.decide(zone, fish, h, now))

            rest = period - (time.perf_counter() - t_tick)
            if rest > 0:
                time.sleep(rest)
        self.release()
        return time.perf_counter() - t_start

    def decide(self, zone, fish, h, now):
        a = self.adv
        A = a["accel"] * h
        a_now = -A if self.held else A
        y, v = zone.predict(now + a["latency_s"], a_now)
        fy, fv = fish.predict(now + a["latency_s"], 0.0)
        target = fy + a["aim_offset"] * h
        stop = y + np.sign(v) * v * v / (2 * A)
        band = a["hysteresis"] * h
        if self.held:
            return stop > target - band
        return stop > target + band

    def maybe_store(self):
        if not self.cfg.get("auto_store", True) or self._stop.is_set():
            return
        v = ui.View(self.screen)
        n = v.hotbar_slots()
        if n <= 1 or n == ui.MAX_SLOTS:
            return
        self.state = "storing"
        self.status("storing an item from the hotbar")
        storage.store_extras(self.screen, self.cfg, self.status, lambda: self._stop.is_set())

    def maybe_bait(self):
        for attempt in range(2):
            row, switched = baits.ensure_bait(self.screen, self.cfg, self.status, lambda: self._stop.is_set())
            if row is not None:
                self.bait_name = row.name
                self.bait = row.count
            if not switched or self._stop.is_set():
                return
            self.rod_off_on("bait switched - rod off and on so the click doesn't count as a cast")
            if row is None or row.selected or self._stop.is_set():
                return

    def rod_off_on(self, why):
        k = self.cfg["rod_key"]
        self.status(why)
        inputs.press(k)
        time.sleep(0.7)
        inputs.press(k)
        time.sleep(0.7)
        storage.ensure_rod(self.screen, self.cfg, self.status, lambda: self._stop.is_set())

    def run_time(self):
        run = int(time.monotonic() - self._run_started)
        return "%d:%02d:%02d" % (run // 3600, run // 60 % 60, run % 60)

    def ping(self, payload):
        uid = str(self.cfg.get("webhook_user") or "")
        if uid:
            payload["content"] = "<@%s>" % uid
            payload["allowed_mentions"] = {"users": [uid]}
        else:
            payload["allowed_mentions"] = {"parse": []}
        return payload

    def send_webhook(self, payload, what):
        try:
            frame = webhook.capture_roblox()
        except Exception:
            frame = None
        report = lambda msg: self.status("webhook %s: %s" % (what, msg))
        if self.webhook.send(str(self.cfg.get("webhook_url") or ""), payload, frame, report):
            return True
        report("still sending the last one, skipped")
        return False

    def test_webhook(self):
        if not self.cfg.get("webhook_url"):
            self.status("Paste your webhook URL first.")
            return
        self.status("Sending a test to the webhook...")
        payload = self.ping({"embeds": [webhook.embed("Webhook works :)", 0x5865F2, [], "Test from 1vtt's GPO Fishing Macro.")]})
        threading.Thread(target=self.send_webhook, args=(payload, "test"), daemon=True).start()

    def on_catch(self):
        self._last_catch = time.monotonic()
        self._fail_sent = False
        self._dc_sent = 0
        if not self.cfg.get("webhook_url"):
            return
        if self.name_read_on():
            threading.Thread(target=self.log_named_catch, daemon=True).start()
            return
        if not self.cfg.get("webhook_enabled"):
            return
        fields = [("Catch", "#%d" % self.catches), ("Running for", self.run_time())]
        if self.bait_name:
            fields.append(("Bait", self.bait_name + ("" if self.bait is None else " x%d" % self.bait)))
        payload = {"allowed_mentions": {"parse": []}, "embeds": [webhook.embed("Fish Caught :)", CAUGHT_COLOR, fields)]}
        self.send_webhook(payload, "catch")

    def read_fish_name(self):
        seen = []
        for i in range(NAME_READ_TRIES):
            try:
                frame = webhook.capture_roblox()
            except Exception:
                frame = None
            name = self.names.read(names.area_crop(frame, self.cfg.get("name_area")))
            if name:
                seen.append(name)
            if i + 1 < NAME_READ_TRIES and self._stop.wait(NAME_READ_GAP_S):
                break
        return names.most_common(seen)

    def log_named_catch(self):
        if self._stop.wait(float(self.adv.get("name_read_delay_s", 0.1))):
            return
        name = self.read_fish_name()
        with self._tally_lock:
            if name:
                what = next((k for k in self.tally if names.same_fish(k, name)), name)
                self.tally[what] = self.tally.get(what, 0) + 1
            else:
                self.unread += 1
                what = "name not read: %s" % self.names.why
            self.last_fish = what
            payload = self.log_payload()
        self.live_log.update(str(self.cfg.get("webhook_url") or ""), payload,
                             lambda msg: self.status("webhook fish log (%s): %s" % (what, msg)))

    def log_payload(self):
        items = sorted(self.tally.items(), key=lambda kv: -kv[1])
        lines = ["%s %s x%d" % (FISH_MARK, fish, n) for fish, n in items]
        shown = []
        for line in lines:
            if len("\n".join(shown + [line])) > LOG_TEXT_MAX:
                break
            shown.append(line)
        if len(shown) < len(lines):
            shown.append("...and %d more" % (len(lines) - len(shown)))
        fields = [("Caught", str(sum(self.tally.values()))), ("Name not read", str(self.unread)),
                  ("Running for", self.run_time())]
        if self.bait_name:
            fields.append(("Bait", self.bait_name + ("" if self.bait is None else " x%d" % self.bait)))
        log = webhook.embed("Fishing Log", CAUGHT_COLOR, fields, "\n" + ("\n".join(shown) or "No fish yet"))
        return {"allowed_mentions": {"parse": []}, "embeds": [log]}

    def test_name_read(self):
        if not self.cfg.get("name_area"):
            self.status("Select the name area first.")
            return
        self.status("Reading the name area...")

        def run():
            try:
                frame = webhook.capture_roblox()
            except Exception:
                frame = None
            crop = names.area_crop(frame, self.cfg.get("name_area"))
            if crop is None:
                self.status("Roblox not found, open it first.")
                return
            name = self.names.read(crop)
            self.status("Read: %s" % name if name else "Couldn't read a name (%s)." % self.names.why)

        threading.Thread(target=run, daemon=True).start()

    def fail_watch(self):
        while not self._stop.wait(1.0):
            if not self.cfg.get("webhook_url"):
                continue
            idle = time.monotonic() - self._last_catch
            fields = [("Catches", str(self.catches)), ("Running for", self.run_time())]
            if self.cfg.get("webhook_dc") and idle >= (self._dc_sent + 1) * WEBHOOK_DC_SEC:
                payload = self.ping({"embeds": [webhook.embed("Possibly disconnected OR griefed", ALERT_COLOR, fields,
                                                              "No fish caught in the last %d minutes." % (int(idle) // 60))]})
                if self.send_webhook(payload, "disconnect alert"):
                    self._dc_sent = int(idle // WEBHOOK_DC_SEC)
                continue
            if self._fail_sent or not self.cfg.get("webhook_fail") or idle < WEBHOOK_FAIL_SEC:
                continue
            payload = self.ping({"embeds": [webhook.embed("Something failed :(", ALERT_COLOR, fields,
                                                          "No fish caught in the last %d seconds." % WEBHOOK_FAIL_SEC)]})
            self._fail_sent = self.send_webhook(payload, "fail alert")

    def maybe_shop(self):
        if not self.cfg["auto_buy_bait"] or self._stop.is_set():
            return
        every = int(self.cfg["buy_bait_every"])
        if self.catches - self._last_shop < max(1, int(self.cfg["shop"].get("retry_after", 10))) \
                and self._last_shop_failed:
            return
        below = int(self.cfg["shop"].get("buy_when_bait_below") or 0)
        if below > 0:
            bait = ui.read_bait(ui.View(self.screen), "common")
            if bait is not None:
                self.status("caught one  total: %d  common bait: %d" % (self.catches, bait))
                if bait >= below:
                    return
            elif self.catches - self._last_shop < every:
                return
        elif self.catches - self._last_shop < every:
            return
        self.state = "buying bait"
        self.status("buying bait")
        ok = shop.buy_bait(self.screen, self.cfg["shop"], self.status, lambda: self._stop.is_set())
        self._last_shop = self.catches
        self._last_shop_failed = not ok
        if not ok and not self._stop.is_set():
            self.status("shop: no bait bought - trying again in %d catches" %
                        max(1, int(self.cfg["shop"].get("retry_after", 10))))
        storage.ensure_rod(self.screen, self.cfg, self.status, lambda: self._stop.is_set())

    def _run(self):
        try:
            self.screen = capture.Screen()
            self._last_shop = self.catches
            self._last_shop_failed = False
            self._run_started = time.monotonic()
            self._last_catch = self._run_started
            self._fail_sent = False
            self._dc_sent = 0
            with self._tally_lock:
                self.tally = {}
                self.unread = 0
                self.last_fish = None
            self.live_log.reset()
            if self.cfg.get("webhook_url") and self.name_read_on():
                self.warm_names()
            threading.Thread(target=self.fail_watch, daemon=True).start()
            if not inputs.focus_roblox():
                self.status("running - click into Roblox")
            while not self._stop.is_set():
                self.state = "casting"
                self.status("casting")
                storage.ensure_rod(self.screen, self.cfg, self.status, lambda: self._stop.is_set())
                if self._stop.is_set():
                    break
                self.maybe_bait()
                if self._stop.is_set():
                    break
                self.cast()
                self.state = "waiting"
                self.status("waiting for the minigame")
                bar, timed_out = self.wait_for_bar()
                if bar is None:
                    if timed_out:
                        self.reset_rod()
                    continue
                self.last_bar = bar
                self.state = "playing"
                self.status("minigame - bar %dx%dpx" % (bar.width, bar.height))
                dur = self.play(bar)
                if self._stop.is_set():
                    break
                self.catches += 1
                self.status("caught one after %.1fs  total: %d" % (dur, self.catches))
                self.on_catch()
                self._idle(self.cfg["recast_delay_s"])
                self.maybe_store()
                self.maybe_shop()
        except Exception as exc:
            self.status("error: %s" % exc)
        finally:
            self.release()
            self.state = "idle"
